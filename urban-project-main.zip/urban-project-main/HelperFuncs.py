import pandas as pd
import numpy as np
import geopandas as gpd
import shapely
import glob
import os
import re
import h3
import re
from shapely.geometry import Polygon


def walk_sub_dirs(root_path, skip_paths):
    paths = []
    for subdir, dirs, files in os.walk(root_path):
        for skip in skip_paths:
            if skip in dirs:
                dirs.remove(skip)
        file = glob.glob(os.path.join(subdir, "*.csv"))
        if len(file) > 0:
            paths.append(file[0])  # Currently only expecting one csv file in each folder
    return paths


def find_filepath_by_regex(regex_str, file_paths):
    paths = []
    regex = re.compile(regex_str)
    for i, file in enumerate(file_paths):
        if regex.findall(file):
            paths.append(file_paths[i])
    return paths


def find_filepath_by_regex(regex_str, file_paths):
    paths = []
    regex = re.compile(regex_str)
    for i, file in enumerate(file_paths):
        if regex.findall(file):
            paths.append(file_paths[i])
    return paths


def add_geometry(row):
    points = h3.h3_to_geo_boundary(row['h3_idx'], True)  # True to flip lat/lon coordinates
    return Polygon(points)


def apply_crs_4326(df):
    df.crs = "EPSG:4326"
    df["geometry"].to_crs(4326)
    return df


def apply_h3_grid_to_file(basefile, new_filename, res):
    """
    Applies H3 grids from file, and creates a new geojson file with geometries and encoding from chosen encoding

    :param old_file_name:
    :param new_filename:
    :param res: applies chosen resolution to new file
    :return: creates a new file
    """
    gdf_h3 = gpd.read_file(basefile)
    gdf_h3['resolution'] = gdf_h3['resolution'].astype('int64')
    gdf_h3['geometry'] = gdf_h3.apply(add_geometry, axis=1)
    df_applied = gdf_h3.loc[gdf_h3["resolution"] == res]
    df_applied = apply_crs_4326(df_applied)
    df_applied.to_file("./Data/" + new_filename + ".geojson", driver='GeoJSON')


# apply_h3_grid_to_file("/Data/gbg_h3_osmids_central.csv", "h3_res11_central", 11)

def get_total_trip_count(edgeids, edge_id_to_trip_count):
    sum = 0
    for edge in edgeids:
        if int(edge) in edge_id_to_trip_count:
            sum += edge_id_to_trip_count.get(int(edge))
    return sum


def apply_strava_counts_to_hexagons(strava_file, h3_file):
    df = pd.read_csv(strava_file)
    gdf_h3 = gpd.read_file(h3_file)
    gdf_counts = df.groupby("edge_uid").sum().reset_index()[["edge_uid", "total_trip_count"]]
    gdf_counts.set_index(keys=["edge_uid"], inplace=True)  # Set index on edge_uid
    edge_id_to_trip_count = gdf_counts['total_trip_count'].to_dict()
    gdf_h3["edgeuids"] = gdf_h3["edgeuids"].apply(lambda x: x[1:-1].split(','))  # Convert str({}) to [str]
    gdf_h3['total_trip_count'] = gdf_h3['edgeuids'].apply(get_total_trip_count, args=(edge_id_to_trip_count,))
    return gdf_h3

"""
file1 = "/Users/oscarrosberg/Documents/Applied Data Science/Project Course/Data/raw_data/selected_area_monthly_2019-01-01-2019-12-31_ride/3dccf5725ca72fd38647b71c8278b9847f38bfbd7fdecdf2525c8ffa04a25097-1689201537595.csv"
file2 = "/Users/oscarrosberg/Documents/Applied Data Science/Project Course/Data/h3_res11_central.geojson"
gdf = apply_strava_counts_to_hexagons(file1, file2)
print(gdf["total_trip_count"].median())
"""